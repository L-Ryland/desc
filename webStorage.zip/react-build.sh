#!/bin/bash

cd web
npm run build --verbose
cd -
